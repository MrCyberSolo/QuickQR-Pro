const express = require('express');
const cors = require('cors');
const QRCode = require('qrcode');
const path = require('path');
const fs = require('fs');
const multer = require('multer');
const jwt = require('jsonwebtoken');

// Create Express app
const app = express();
const PORT = process.env.PORT || 3002;

// Set up multer for file uploads
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    const publicDir = path.join(__dirname, '../../public');
    // Create directory if it doesn't exist
    if (!fs.existsSync(publicDir)) {
      fs.mkdirSync(publicDir, { recursive: true });
    }
    cb(null, publicDir);
  },
  filename: function (req, file, cb) {
    // Keep original filename for favicon
    if (file.fieldname === 'favicon') {
      cb(null, 'favicon.ico');
    } else {
      cb(null, file.originalname);
    }
  }
});

const upload = multer({ storage: storage });

// Enable CORS for all routes with specific options
app.use(cors({
  origin: ['http://dynamic-balancig.com', 'http://dynamic-balancig.com'],
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization']
}));

// Handle preflight requests with the same CORS settings

// Parse JSON body
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve static files from the public directory
app.use(express.static(path.join(__dirname, '../../public')));

// Create a directory for storing generated QR codes
const qrImagesDir = path.join(__dirname, 'qr-images');
if (!fs.existsSync(qrImagesDir)) {
  fs.mkdirSync(qrImagesDir, { recursive: true });
}

// Define the path for site configuration
const CONFIG_PATH = path.resolve(__dirname, '../data/siteConfig.json');
console.log('Config path:', CONFIG_PATH);

// Ensure the data directory exists
const dataDir = path.dirname(CONFIG_PATH);
if (!fs.existsSync(dataDir)) {
  console.log('Creating data directory:', dataDir);
  fs.mkdirSync(dataDir, { recursive: true });
}

// Helper function to generate QR code
const generateQRCode = async (data, options = {}) => {
  const defaultOptions = {
    errorCorrectionLevel: 'H',
    type: 'image/png',
    quality: 0.92,
    margin: 1,
    color: {
      dark: '#000000',
      light: '#FFFFFF'
    }
  };

  const mergedOptions = { ...defaultOptions, ...options };
  
  try {
    const qrImage = await QRCode.toDataURL(data, mergedOptions);
    return qrImage;
  } catch (error) {
    console.error('Error generating QR code:', error);
    throw error;
  }
};

// QR Code generation endpoint
app.get('/api/qr/generate', async (req, res) => {
  try {
    const { data, size = 300, format = 'png', foreground = '#000000', background = '#FFFFFF' } = req.query;
    
    if (!data) {
      return res.status(400).json({ error: 'Missing required parameter: data' });
    }
    
    const options = {
      width: parseInt(size, 10),
      type: format === 'svg' ? 'svg' : 'image/png',
      color: {
        dark: foreground,
        light: background
      }
    };
    
    const qrImage = await generateQRCode(data, options);
    
    if (format === 'json') {
      res.json({ qrcode: qrImage });
    } else {
      // For direct image response, we need to convert the data URL to a buffer
      const imageData = qrImage.replace(/^data:image\/png;base64,/, '');
      const imageBuffer = Buffer.from(imageData, 'base64');
      
      res.set('Content-Type', 'image/png');
      res.send(imageBuffer);
    }
  } catch (error) {
    console.error('Error handling QR code generation request:', error);
    res.status(500).json({ error: 'Failed to generate QR code' });
  }
});

// Type-specific QR code generation endpoints
app.get('/api/qr/type/:type', async (req, res) => {
  try {
    const { type } = req.params;
    const { size = 300, format = 'png', foreground = '#000000', background = '#FFFFFF' } = req.query;
    
    let data;
    let error = null;
    
    // Validate and construct data based on type
    switch (type) {
      case 'url':
        const { url } = req.query;
        if (!url) {
          error = 'Missing required parameter: url';
        } else {
          data = url;
        }
        break;
        
      case 'wifi':
        const { ssid, password, encryption = 'WPA' } = req.query;
        if (!ssid) {
          error = 'Missing required parameter: ssid';
        } else {
          data = `WIFI:S:${ssid};T:${encryption};P:${password || ''};;`;
        }
        break;
        
      case 'vcard':
        const { name, phone, email, company, title, url: website } = req.query;
        if (!name) {
          error = 'Missing required parameter: name';
        } else {
          data = 'BEGIN:VCARD\nVERSION:3.0\n';
          data += `FN:${name}\n`;
          if (phone) data += `TEL:${phone}\n`;
          if (email) data += `EMAIL:${email}\n`;
          if (company) data += `ORG:${company}\n`;
          if (title) data += `TITLE:${title}\n`;
          if (website) data += `URL:${website}\n`;
          data += 'END:VCARD';
        }
        break;
        
      case 'email':
        const { address, subject, body } = req.query;
        if (!address) {
          error = 'Missing required parameter: address';
        } else {
          data = `mailto:${address}`;
          const params = [];
          if (subject) params.push(`subject=${encodeURIComponent(subject)}`);
          if (body) params.push(`body=${encodeURIComponent(body)}`);
          if (params.length > 0) {
            data += `?${params.join('&')}`;
          }
        }
        break;
        
      case 'sms':
        const { phone: phoneNumber, message } = req.query;
        if (!phoneNumber) {
          error = 'Missing required parameter: phone';
        } else {
          data = `sms:${phoneNumber}`;
          if (message) {
            data += `?body=${encodeURIComponent(message)}`;
          }
        }
        break;
        
      case 'geo':
        const { lat, lng, q } = req.query;
        if (q) {
          data = `geo:0,0?q=${encodeURIComponent(q)}`;
        } else if (lat && lng) {
          data = `geo:${lat},${lng}`;
        } else {
          error = 'Missing required parameters: either lat and lng, or q';
        }
        break;
        
      default:
        error = `Unsupported QR code type: ${type}`;
    }
    
    if (error) {
      return res.status(400).json({ error });
    }
    
    const options = {
      width: parseInt(size, 10),
      type: format === 'svg' ? 'svg' : 'image/png',
      color: {
        dark: foreground,
        light: background
      }
    };
    
    const qrImage = await generateQRCode(data, options);
    
    if (format === 'json') {
      res.json({ qrcode: qrImage });
    } else {
      // For direct image response, we need to convert the data URL to a buffer
      const imageData = qrImage.replace(/^data:image\/png;base64,/, '');
      const imageBuffer = Buffer.from(imageData, 'base64');
      
      res.set('Content-Type', 'image/png');
      res.send(imageBuffer);
    }
  } catch (error) {
    console.error('Error handling type-specific QR code generation:', error);
    res.status(500).json({ error: 'Failed to generate QR code' });
  }
});

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// JWT Secret for token signing
const JWT_SECRET = 'quickqr-admin-secret-key-2025';

// Middleware to verify JWT token
const verifyToken = (req, res, next) => {
  // Skip authentication for login endpoint and test endpoint
  if (req.path === '/api/admin/login' || req.path === '/api/admin/test') {
    return next();
  }
  
  // For debugging
  console.log('Request path:', req.path);
  console.log('Headers:', req.headers);
  
  const authHeader = req.headers.authorization;
  if (!authHeader) {
    console.log('No authorization header');
    return res.status(401).json({ message: 'No token provided' });
  }
  
  const token = authHeader.split(' ')[1];
  if (!token) {
    console.log('Invalid token format');
    return res.status(401).json({ message: 'Invalid token format' });
  }
  
  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    req.user = decoded;
    console.log('Token verified successfully for user:', decoded.username);
    next();
  } catch (error) {
    console.log('Token verification error:', error.message);
    return res.status(401).json({ message: 'Invalid token' });
  }
};

// Test endpoint to verify API is working
app.get('/api/admin/test', (req, res) => {
  res.json({ message: 'API is working correctly', timestamp: new Date().toISOString() });
});

// Admin API endpoints

// Admin login endpoint
app.post('/api/admin/login', async (req, res) => {
  try {
    console.log('Login request received:', req.body);
    const { username, password } = req.body;
    
    // Read config file to get admin credentials
    if (!fs.existsSync(CONFIG_PATH)) {
      console.log('Config file not found during login');
      return res.status(404).json({ message: 'Configuration file not found' });
    }
    
    const configData = fs.readFileSync(CONFIG_PATH, 'utf8');
    const config = JSON.parse(configData);
    
    console.log('Admin credentials from config:', config.admin);
    console.log('Provided credentials:', { username, password });
    
    // Check credentials
    if (!config.admin || username !== config.admin.username || password !== config.admin.password) {
      console.log('Invalid credentials');
      return res.status(401).json({ message: 'Invalid username or password' });
    }
    
    // Generate JWT token
    const token = jwt.sign({ username }, JWT_SECRET, { expiresIn: '1h' });
    console.log('Login successful, token generated:', token);
    
    // Set CORS headers explicitly for this response
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization');
    
    // Send token in response
    res.json({ token, message: 'Login successful' });
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ message: 'Login failed: ' + error.message });
  }
});

// Verify token endpoint
app.get('/api/admin/verify', verifyToken, (req, res) => {
  res.json({ valid: true, user: req.user });
});

// Get site configuration
app.get('/api/admin/config', verifyToken, (req, res) => {
  try {
    console.log('GET request to /api/admin/config');
    console.log('Checking if config file exists at:', CONFIG_PATH);
    
    if (!fs.existsSync(CONFIG_PATH)) {
      console.log('Config file not found, creating default config');
      // Create default config if it doesn't exist
      const defaultConfig = {
        "seo": {
          "title": "QuickQR Pro - Easy QR Code Generator",
          "description": "Generate customizable QR codes for URLs, WiFi, vCards, and more with QuickQR Pro. No sign-up required.",
          "keywords": "QR code, QR generator, QR code maker, free QR code, custom QR",
          "ogImage": "/images/og-image.png",
          "twitterCard": "summary_large_image",
          "favicon": "/favicon.ico"
        },
        "branding": {
          "siteName": "QuickQR Pro",
          "logo": "/images/logo.svg",
          "primaryColor": "#4F46E5",
          "secondaryColor": "#818CF8"
        },
        "contact": {
          "email": "support@quickqrpro.com",
          "twitter": "@quickqrpro",
          "github": "quickqrpro"
        },
        "features": {
          "enableAnalytics": true,
          "enableTemplates": true,
          "enableCustomization": true,
          "enableBulkGeneration": false
        }
      };
      
      fs.writeFileSync(CONFIG_PATH, JSON.stringify(defaultConfig, null, 2), 'utf8');
      return res.json(defaultConfig);
    }
    
    console.log('Config file found, reading content');
    const configData = fs.readFileSync(CONFIG_PATH, 'utf8');
    console.log('Config data read, parsing JSON');
    const config = JSON.parse(configData);
    console.log('Config parsed successfully');
    
    res.json(config);
  } catch (error) {
    console.error('Error reading config:', error);
    res.status(500).json({ message: 'Failed to read configuration: ' + error.message });
  }
});

// Update site configuration
app.post('/api/admin/config', verifyToken, upload.single('favicon'), (req, res) => {
  try {
    let config;
    
    if (req.body.config) {
      config = JSON.parse(req.body.config);
    } else {
      return res.status(400).json({ message: 'No configuration data provided' });
    }
    
    // If a favicon was uploaded, update the path
    if (req.file) {
      // Update the favicon path in the config
      config.seo.favicon = '/favicon.ico';
    }
    
    // Write the updated config to the file
    fs.writeFileSync(CONFIG_PATH, JSON.stringify(config, null, 2));
    
    res.json({ message: 'Configuration updated successfully' });
  } catch (error) {
    console.error('Error updating config:', error);
    res.status(500).json({ message: 'Failed to update configuration' });
  }
});

// Start the server
app.listen(PORT, () => {
  console.log(`QR Code API server running on port ${PORT}`);
});

module.exports = app;
